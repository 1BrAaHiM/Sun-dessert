# Petal & Crumb — Angular

A boutique-bakery homepage built with Angular 18 (standalone components), inspired by the
layout patterns of modern bakery e-commerce sites: sticky header with announcement bar,
a full-bleed hero, an asymmetric promo grid, a delivery-options section, and a split
catering banner.

## Structure

```
src/app/
  app.component.ts / .html          — shell that assembles the sections
  components/
    header/            — announcement bar + sticky nav
    hero/              — hero banner
    promo-grid/        — data-driven promo tiles (edit `cards` in .ts)
    delivery-options/  — 3-up delivery/pickup/catering cards
    catering/          — split image/copy banner
    footer/            — footer with data-driven link columns
```

Colors, fonts, and spacing are defined as CSS custom properties in `src/styles.css`
(`--cream`, `--blush`, `--rose`, `--rose-deep`, `--ink`, `--gold`) — change these to
re-theme the whole site.

## Run it

```bash
npm install
npm start        # ng serve, http://localhost:4200
npm run build     # production build to dist/petal-crumb
```

Requires Node 18+ and npm. This was scaffolded with `@angular/cli@18`.
