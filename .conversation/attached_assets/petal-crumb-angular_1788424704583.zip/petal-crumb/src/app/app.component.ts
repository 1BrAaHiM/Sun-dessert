import { Component } from '@angular/core';
import { HeaderComponent } from './components/header/header.component';
import { HeroComponent } from './components/hero/hero.component';
import { PromoGridComponent } from './components/promo-grid/promo-grid.component';
import { DeliveryOptionsComponent } from './components/delivery-options/delivery-options.component';
import { CateringComponent } from './components/catering/catering.component';
import { FooterComponent } from './components/footer/footer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    HeaderComponent,
    HeroComponent,
    PromoGridComponent,
    DeliveryOptionsComponent,
    CateringComponent,
    FooterComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'petal-crumb';
}
