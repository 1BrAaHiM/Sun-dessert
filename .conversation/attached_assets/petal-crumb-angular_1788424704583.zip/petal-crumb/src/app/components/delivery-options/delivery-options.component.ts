import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface DeliveryOption {
  icon: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-delivery-options',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delivery-options.component.html',
  styleUrl: './delivery-options.component.css'
})
export class DeliveryOptionsComponent {
  options: DeliveryOption[] = [
    {
      icon: '🎀',
      title: 'Nationwide Shipping',
      description: 'Cupcakes, cakes and pudding, packed fresh and shipped to your door.'
    },
    {
      icon: '🧁',
      title: 'Local Pickup',
      description: 'Place an advance order and swing by your neighborhood bakery.'
    },
    {
      icon: '🎉',
      title: 'Catering & Events',
      description: 'Custom spreads for offices, weddings and everything between.'
    }
  ];
}
