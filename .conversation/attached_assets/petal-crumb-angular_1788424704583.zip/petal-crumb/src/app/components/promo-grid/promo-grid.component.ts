import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface PromoCard {
  title: string;
  description: string;
  cta: string;
  size: 'large' | 'medium-a' | 'medium-b';
}

@Component({
  selector: 'app-promo-grid',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './promo-grid.component.html',
  styleUrl: './promo-grid.component.css'
})
export class PromoGridComponent {
  cards: PromoCard[] = [
    {
      title: 'The Banana Pudding Bar',
      description: 'Build your own bowl, layer by layer, at our all-new pudding counter.',
      cta: 'Learn more',
      size: 'large'
    },
    {
      title: 'Cookie Butter Season',
      description: 'Our fall favorite is back for a limited run.',
      cta: 'Order now',
      size: 'medium-a'
    },
    {
      title: 'Cupcake Decorating Class',
      description: 'Learn our signature swirl, hands-on.',
      cta: 'Get tickets',
      size: 'medium-b'
    }
  ];
}
