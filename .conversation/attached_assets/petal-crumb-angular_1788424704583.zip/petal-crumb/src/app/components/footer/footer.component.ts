import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface FooterColumn {
  heading: string;
  links: string[];
}

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  year = new Date().getFullYear();

  columns: FooterColumn[] = [
    { heading: 'Shop', links: ['Cupcakes', 'Cakes', 'Banana Pudding', 'Gift Boxes'] },
    { heading: 'Company', links: ['Our Story', 'Locations', 'Franchising', 'Careers'] },
    { heading: 'Get in touch', links: ['Contact Us', 'Catering & Events', 'FAQs'] }
  ];
}
